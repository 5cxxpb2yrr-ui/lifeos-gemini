# Mission Control UI (apps/web/src/mission)

Self-contained port of the LifeOS Mission Control prototype. Nothing outside this folder is touched, so it will not overwrite your existing `App.tsx`, `lifeosTheme.ts` or global CSS.

## Mount it
```tsx
import MissionApp from './mission/MissionApp';
// render <MissionApp /> where you want it (for example, replace the Mission route's content)
```

## Needs (add if missing in apps/web)
- dependencies: `react`, `react-dom`, `zustand`; Tailwind already configured (classes use arbitrary values and CSS variables, no config changes)
- devDependencies for the tests: `vitest`, `typescript`, `@types/react`, `@types/react-dom` (`pnpm --filter web vitest run src/mission`, 20 tests)
- Tailwind `content` must include `./src/**/*.{ts,tsx}` (normal Vite setup)

## Reconcile with what you have
- `mission/theme/lifeosTheme.ts` duplicates your existing `lifeosTheme`. Point `mission/` at yours (or yours at this one) once you have compared values: radius 28/20, motion 120/180/240ms, impact bands.
- `mission/theme/tokens.css` defines CSS variables only (`--bg`, `--surface-1..3`, `--blue`, ...). No global body styles.
- `store.ts` persists to localStorage under `lifeos-mission-control`. It starts from `seed.ts`. Replace with API calls to the Fastify backend when ready: `lib/resolve.ts` is pure and takes records, so it can run in the client or server.

## Layout
- `lib/` pure, tested domain logic: scoring, resolve, ledger, loans, agenda, health, capture, dates
- `components/` cards, Sheet, BillSheet, PersonSheet, OptionsPanel, forms, chart
- `screens/` Mission, Inbox, Entities, Search, More, and the secondary views

## Not done
- No `>project` / `^goal` linking (the seed has no such records).
- Calendar links open Google Calendar; there is no sync.
- No backend or SurrealDB wiring.
